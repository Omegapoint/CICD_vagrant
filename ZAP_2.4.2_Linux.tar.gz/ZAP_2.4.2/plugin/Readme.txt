# This directory is for ZAP add-ons
# The 'built-in' add-ons are no longer stored in this directory in source control due to space issues.
# Use the relevant zap-extensions build tasks to deploy the add-ons you want to use.